vuser_end()
{

	/* home */

	lr_think_time(40);

	web_url("home", 
		"URL=http://uitestingplayground.com/home", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://uitestingplayground.com/dynamicid", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}