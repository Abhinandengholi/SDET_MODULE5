Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=121", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	web_url("katalon-demo-cura.herokuapp.com", 
		"URL=https://katalon-demo-cura.herokuapp.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	web_concurrent_start(NULL);

	web_url("header.jpg", 
		"URL=https://katalon-demo-cura.herokuapp.com//img/header.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://katalon-demo-cura.herokuapp.com//css/theme.css", 
		"Snapshot=t3.inf", 
		LAST);

	web_url("6xK3dSBYKcSV-LCoeQqfX1RYOo3qOK7l.woff2", 
		"URL=https://fonts.gstatic.com/s/sourcesanspro/v22/6xK3dSBYKcSV-LCoeQqfX1RYOo3qOK7l.woff2", 
		"Resource=1", 
		"RecContentType=font/woff2", 
		"Referer=https://fonts.googleapis.com/", 
		"Snapshot=t4.inf", 
		LAST);

	web_url("6xKydSBYKcSV-LCoeQqfX1RYOo3ig4vwlxdu.woff2", 
		"URL=https://fonts.gstatic.com/s/sourcesanspro/v22/6xKydSBYKcSV-LCoeQqfX1RYOo3ig4vwlxdu.woff2", 
		"Resource=1", 
		"RecContentType=font/woff2", 
		"Referer=https://fonts.googleapis.com/", 
		"Snapshot=t5.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_set_sockets_option("TLS_SNI", "1");

	/* Appointment */

	lr_think_time(29);

	web_link("Login", 
		"Text=Login", 
		"Snapshot=t6.inf", 
		LAST);

	/* login */

	web_submit_form("authenticate.php", 
		"Snapshot=t7.inf", 
		ITEMDATA, 
		"Name=username", "Value={userNme}", ENDITEM, 
		"Name=password", "Value={{passWord}}", ENDITEM, 
		LAST);


	lr_think_time(13);
	/* book appointment */

	lr_think_time(6);

	web_submit_data("appointment.php", 
		"Action=https://katalon-demo-cura.herokuapp.com/appointment.php", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://katalon-demo-cura.herokuapp.com/", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=facility", "Value=Tokyo CURA Healthcare Center", ENDITEM, 
		"Name=hospital_readmission", "Value=Yes", ENDITEM, 
		"Name=programs", "Value=Medicare", ENDITEM, 
		"Name=visit_date", "Value=14/02/2024", ENDITEM, 
		"Name=comment", "Value=", ENDITEM, 
		LAST);

	
	return 0;
}