Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=121", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("__Host-GAPS=1:rk_OScmwM59WV1iNHOSXeXCb2_MbHw:WWGvEYcXZ2J4YS11; DOMAIN=accounts.google.com");

	web_add_cookie("OGPC=19037049-1:; DOMAIN=accounts.google.com");

	web_add_cookie("1P_JAR=2024-02-06-09; DOMAIN=accounts.google.com");

	web_add_cookie("AEC=Ae3NU9Nw1IwY43SdO1ZXxYdDkR6ejEu_BMeaUGmNO50NwwjPAd0GH5f3E5Q; DOMAIN=accounts.google.com");

	web_add_cookie("NID=511=DLMHjpEXXFRupbi7zCHF0mOXB4qdIEeVT5wAMUXS3Pb7pOK-gv5OuZJbuTKIRw23vOQVLq_Oofvf9WvhJsJTRDUeh7G5M4Fdy5cH0L9zQDCRB7AtQVy5AeeRnGqxtYp-Il09n0RotRT6-tOc75omiBASrUflw1qM35u_pK_r9ZgQulowf5h9GX55KImkrSFgDXcZPUqzGw; DOMAIN=accounts.google.com");

	web_custom_request("ListAccounts", 
		"URL=https://accounts.google.com/ListAccounts?gpsia=1&source=ChromiumBrowser&json=standard", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		"Body= ", 
		LAST);

	web_concurrent_start(NULL);

	web_url("rs=AA2YrTtkjt2EctqOb9JozsNi632JEdnRdg", 
		"URL=https://www.gstatic.com/og/_/ss/k=og.qtm.uvrAew1hc4Q.L.W.O/m=qcwid/excm=qaaw,qadd,qaid,qein,qhaw,qhba,qhbr,qhch,qhga,qhid,qhin/d=1/ed=1/ct=zgms/rs=AA2YrTtkjt2EctqOb9JozsNi632JEdnRdg", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://www.google.com/", 
		"Snapshot=t28.inf", 
		LAST);

	web_url("rs=AA2YrTuKAn3-aelv4toOlCHsuXvLz49A7Q", 
		"URL=https://www.gstatic.com/og/_/js/k=og.qtm.en_US.cuMvG2lQ980.2019.O/rt=j/m=qabr,q_d,qcwid,qapid,qald,q_dg/exm=qaaw,qadd,qaid,qein,qhaw,qhba,qhbr,qhch,qhga,qhid,qhin/d=1/ed=1/rs=AA2YrTuKAn3-aelv4toOlCHsuXvLz49A7Q", 
		"Resource=1", 
		"RecContentType=text/javascript", 
		"Referer=https://www.google.com/", 
		"Snapshot=t29.inf", 
		LAST);

	web_url("ChVDaHJvbWUvMTIxLjAuNjE2Ny4xNDASGQn11VQ7sgCk8RIFDWlIR0chrbMLunyG1js=", 
		"URL=https://content-autofill.googleapis.com/v1/pages/ChVDaHJvbWUvMTIxLjAuNjE2Ny4xNDASGQn11VQ7sgCk8RIFDWlIR0chrbMLunyG1js=?alt=proto", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t30.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_add_cookie("1P_JAR=2024-02-07-10; DOMAIN=ogs.google.com");

	web_add_cookie("AEC=Ae3NU9NxsiDJPGaSOttHNTm35iDyOeQ4hd624gHurZbEnJWNExhMI6WPIQ; DOMAIN=ogs.google.com");

	web_add_cookie("NID=511=KIptahIZtmKCIHVaRCQDhJdnaFWYMDwRJJyQ4hO23bo7Jgk5a1rycXUr7FueziYChjtP-Vb2MW9gnQ5rhEF9fTlBUmXnRfVpFSN5QUhLRSAeUEeB9MCi8ZKbvoGhhGbeMQn7KO5wYUQLd4SkEcG3e0LHgAxt7W--clEcc4OuwM9EIVRtnpBW-IQ; DOMAIN=ogs.google.com");

	web_url("callout", 
		"URL=https://ogs.google.com/widget/callout?prid=19037050&pgid=19037049&puid=a5627eb5c02923db&cce=1&dc=1&origin=https%3A%2F%2Fwww.google.com&cn=callout&pid=1&spid=538&hl=en", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.google.com/", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("1P_JAR=2024-02-07-10; DOMAIN=apis.google.com");

	web_add_cookie("AEC=Ae3NU9NxsiDJPGaSOttHNTm35iDyOeQ4hd624gHurZbEnJWNExhMI6WPIQ; DOMAIN=apis.google.com");

	web_add_cookie("NID=511=KIptahIZtmKCIHVaRCQDhJdnaFWYMDwRJJyQ4hO23bo7Jgk5a1rycXUr7FueziYChjtP-Vb2MW9gnQ5rhEF9fTlBUmXnRfVpFSN5QUhLRSAeUEeB9MCi8ZKbvoGhhGbeMQn7KO5wYUQLd4SkEcG3e0LHgAxt7W--clEcc4OuwM9EIVRtnpBW-IQ; DOMAIN=apis.google.com");

	web_url("cb=gapi.loaded_0", 
		"URL=https://apis.google.com/_/scs/abc-static/_/js/k=gapi.gapi.en.GsbA68hXs80.O/m=gapi_iframes,googleapis_client/rt=j/sv=1/d=1/ed=1/rs=AHpOoo899t-H8Lxb3OqzMDuPn6TV_i36ag/cb=gapi.loaded_0", 
		"Resource=1", 
		"RecContentType=text/javascript", 
		"Referer=https://www.google.com/", 
		"Snapshot=t32.inf", 
		LAST);

	web_add_cookie("1P_JAR=2024-02-07-10; DOMAIN=play.google.com");

	web_add_cookie("AEC=Ae3NU9NxsiDJPGaSOttHNTm35iDyOeQ4hd624gHurZbEnJWNExhMI6WPIQ; DOMAIN=play.google.com");

	web_add_cookie("NID=511=KIptahIZtmKCIHVaRCQDhJdnaFWYMDwRJJyQ4hO23bo7Jgk5a1rycXUr7FueziYChjtP-Vb2MW9gnQ5rhEF9fTlBUmXnRfVpFSN5QUhLRSAeUEeB9MCi8ZKbvoGhhGbeMQn7KO5wYUQLd4SkEcG3e0LHgAxt7W--clEcc4OuwM9EIVRtnpBW-IQ; DOMAIN=play.google.com");

	web_custom_request("log", 
		"URL=https://play.google.com/log?format=json&hasfast=true", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://www.google.com/", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded;charset=UTF-8", 
		"Body=[[1,null,null,null,null,null,null,null,null,null,[null,null,null,null,\"en-IN\",null,null,null,[[[\"Not A(Brand\",\"99\"],[\"Google Chrome\",\"121\"],[\"Chromium\",\"121\"]],0,\"Windows\",\"10.0.0\",\"x86\",\"\",\"121.0.6167.140\"],[1,0,0,0,0]]],373,[[\"1707300833396\",null,null,null,null,null,null,\"[108,40400,538,1,\\\"604369551.0\\\",\\\"XlrDZaOkNraOseMP-uSZmAM\\\",null,null,null,\\\"en\\\",\\\"IND\\\",0,8,2192,null,0,0,null,\\\"og-93cc141a-2b0f-4971-bb34-1209a3e3a399\\\",null,null,null,"
		"null,null,null,null,0,null,null,null,19037050,null,null,null,null,0,[1],1,null,null,null,null,null,null,null,null,null,null,null,[0,2],null,null,null,null,0,null,[2,5,\\\"sd\\\",162],null,null,0,0,1]\",null,null,null,null,null,null,-19800,[null,null,null,\"[null,null,[3701071,3701290]]\"],null,null,null,null,1],[\"1707300833399\",null,null,null,null,null,null,\"[107,40400,538,1,\\\"604369551.0\\\",\\\"XlrDZaOkNraOseMP-uSZmAM\\\",null,null,null,\\\"en\\\",\\\"IND\\\",0,8,2196,null,0,0,null,\\\""
		"og-93cc141a-2b0f-4971-bb34-1209a3e3a399\\\",null,null,null,null,null,null,null,8,null,null,null,19037050,null,null,null,null,0,[2],2,null,null,null,null,null,null,null,null,null,null,null,[0,2],null,null,null,null,0,null,[2,5,\\\"sd\\\",162],null,null,0,0,1]\",null,null,null,null,null,null,-19800,[null,null,null,\"[null,null,[3701071,3701290]]\"],null,null,null,null,2]],\"1707300834408\",null,null,null,null,null,null,null,null,null,null,null,null,null,[[null,[null,null,null,null,null,null,null,"
		"null,null,null,null,null,122505695]],9]]", 
		LAST);

	web_custom_request("log_2", 
		"URL=https://play.google.com/log?format=json&hasfast=true&authuser=0", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://ogs.google.com/", 
		"Snapshot=t34.inf", 
		"Mode=HTML", 
		LAST);

	/* selecting image */

	/* selecting hindi lanaguage */

	return 0;
}