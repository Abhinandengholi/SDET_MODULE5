Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_url("www.google.com", 
		"URL=https://www.google.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_concurrent_start(NULL);

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=121", 
		"Resource=1", 
		"RecContentType=application/x-gzip", 
		"Referer=", 
		"Snapshot=t2.inf", 
		LAST);

	web_url("rs=AA2YrTtkjt2EctqOb9JozsNi632JEdnRdg", 
		"URL=https://www.gstatic.com/og/_/ss/k=og.qtm.uvrAew1hc4Q.L.W.O/m=qcwid/excm=qaaw,qadd,qaid,qein,qhaw,qhba,qhbr,qhch,qhga,qhid,qhin/d=1/ed=1/ct=zgms/rs=AA2YrTtkjt2EctqOb9JozsNi632JEdnRdg", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://www.google.com/", 
		"Snapshot=t3.inf", 
		LAST);

	web_url("rs=AA2YrTuKAn3-aelv4toOlCHsuXvLz49A7Q", 
		"URL=https://www.gstatic.com/og/_/js/k=og.qtm.en_US.cuMvG2lQ980.2019.O/rt=j/m=qabr,q_d,qcwid,qapid,qald,q_dg/exm=qaaw,qadd,qaid,qein,qhaw,qhba,qhbr,qhch,qhga,qhid,qhin/d=1/ed=1/rs=AA2YrTuKAn3-aelv4toOlCHsuXvLz49A7Q", 
		"Resource=1", 
		"RecContentType=text/javascript", 
		"Referer=https://www.google.com/", 
		"Snapshot=t4.inf", 
		LAST);

	web_url("ChVDaHJvbWUvMTIxLjAuNjE2Ny4xNDASGQn11VQ7sgCk8RIFDWlIR0chrbMLunyG1js=", 
		"URL=https://content-autofill.googleapis.com/v1/pages/ChVDaHJvbWUvMTIxLjAuNjE2Ny4xNDASGQn11VQ7sgCk8RIFDWlIR0chrbMLunyG1js=?alt=proto", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t5.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_add_cookie("NID=511=b4Eq8X0TzVb-ubS9jkx5jEPmBVelVZiwFFWXuV85L5Ik5iLfunqv7KWIVbzb-OCSKJFPMRTo-S1p_9SdDgzxNbh0kPo5YbH8MfnrkuksxsaSst5Yzmf9lmPlS-Zy-p1YSWhJ6ox828RMJI6FLa0KSStWIM557H4ilgk6eGseg4TEQ0JYl7357cJt; DOMAIN=ogs.google.com");

	web_url("callout", 
		"URL=https://ogs.google.com/widget/callout?prid=19037050&pgid=19037049&puid=a5627eb5c02923db&cce=1&dc=1&origin=https%3A%2F%2Fwww.google.com&cn=callout&pid=1&spid=538&hl=en", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.google.com/", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	web_concurrent_start(NULL);

	web_url("KFOmCnqEu92Fr1Mu4mxK.woff2", 
		"URL=https://fonts.gstatic.com/s/roboto/v18/KFOmCnqEu92Fr1Mu4mxK.woff2", 
		"Resource=1", 
		"RecContentType=font/woff2", 
		"Referer=https://ogs.google.com/", 
		"Snapshot=t7.inf", 
		LAST);

	web_url("4Ua_rENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RFD48TE63OOYKtrw2IJllpyk.woff2", 
		"URL=https://fonts.gstatic.com/s/googlesans/v58/4Ua_rENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RFD48TE63OOYKtrw2IJllpyk.woff2", 
		"Resource=1", 
		"RecContentType=font/woff2", 
		"Referer=https://ogs.google.com/", 
		"Snapshot=t8.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_set_sockets_option("TLS_SNI", "1");

	web_custom_request("log", 
		"URL=https://play.google.com/log?format=json&hasfast=true&authuser=0", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://ogs.google.com/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("NID=511=b4Eq8X0TzVb-ubS9jkx5jEPmBVelVZiwFFWXuV85L5Ik5iLfunqv7KWIVbzb-OCSKJFPMRTo-S1p_9SdDgzxNbh0kPo5YbH8MfnrkuksxsaSst5Yzmf9lmPlS-Zy-p1YSWhJ6ox828RMJI6FLa0KSStWIM557H4ilgk6eGseg4TEQ0JYl7357cJt; DOMAIN=apis.google.com");

	web_url("cb=gapi.loaded_0", 
		"URL=https://apis.google.com/_/scs/abc-static/_/js/k=gapi.gapi.en.GsbA68hXs80.O/m=gapi_iframes,googleapis_client/rt=j/sv=1/d=1/ed=1/rs=AHpOoo899t-H8Lxb3OqzMDuPn6TV_i36ag/cb=gapi.loaded_0", 
		"Resource=1", 
		"RecContentType=text/javascript", 
		"Referer=https://www.google.com/", 
		"Snapshot=t10.inf", 
		LAST);

	web_add_cookie("NID=511=b4Eq8X0TzVb-ubS9jkx5jEPmBVelVZiwFFWXuV85L5Ik5iLfunqv7KWIVbzb-OCSKJFPMRTo-S1p_9SdDgzxNbh0kPo5YbH8MfnrkuksxsaSst5Yzmf9lmPlS-Zy-p1YSWhJ6ox828RMJI6FLa0KSStWIM557H4ilgk6eGseg4TEQ0JYl7357cJt; DOMAIN=play.google.com");

	web_add_cookie("OGPC=19037049-1:; DOMAIN=play.google.com");

	web_custom_request("log_2", 
		"URL=https://play.google.com/log?format=json&hasfast=true", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://www.google.com/", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded;charset=UTF-8", 
		"Body=[[1,null,null,null,null,null,null,null,null,null,[null,null,null,null,\"en-IN\",null,null,null,[[[\"Not A(Brand\",\"99\"],[\"Google Chrome\",\"121\"],[\"Chromium\",\"121\"]],0,\"Windows\",\"10.0.0\",\"x86\",\"\",\"121.0.6167.140\"],[1,0,0,0,0]]],373,[[\"1707364848184\",null,null,null,null,null,null,\"[108,40400,538,1,\\\"604369551.0\\\",\\\"TFTEZeuNE9zPseMPjtuekAs\\\",null,null,null,\\\"en\\\",\\\"IND\\\",0,8,5267,null,0,0,null,\\\"og-1f203e31-874b-4a44-bf6e-a57fbdc36c71\\\",null,null,null,"
		"null,null,null,null,0,null,null,null,19037050,null,null,null,null,0,[1],1,null,null,null,null,null,null,null,null,null,null,null,[0,2],null,null,null,null,0,null,[2,5,\\\"sd\\\",95],null,null,0,0,1]\",null,null,null,null,null,null,-19800,[null,null,null,\"[null,null,[3701290]]\"],null,null,null,null,1],[\"1707364848189\",null,null,null,null,null,null,\"[107,40400,538,1,\\\"604369551.0\\\",\\\"TFTEZeuNE9zPseMPjtuekAs\\\",null,null,null,\\\"en\\\",\\\"IND\\\",0,8,5272,null,0,0,null,\\\""
		"og-1f203e31-874b-4a44-bf6e-a57fbdc36c71\\\",null,null,null,null,null,null,null,8,null,null,null,19037050,null,null,null,null,0,[2],2,null,null,null,null,null,null,null,null,null,null,null,[0,2],null,null,null,null,0,null,[2,5,\\\"sd\\\",95],null,null,0,0,1]\",null,null,null,null,null,null,-19800,[null,null,null,\"[null,null,[3701290]]\"],null,null,null,null,2],[\"1707364848728\",null,null,null,null,null,null,\"[109,40400,538,1,\\\"604369551.0\\\",\\\"TFTEZeuNE9zPseMPjtuekAs\\\",null,null,null,\\\""
		"en\\\",\\\"IND\\\",0,8,5811,null,0,0,null,\\\"og-1f203e31-874b-4a44-bf6e-a57fbdc36c71\\\",null,null,null,null,null,null,null,32936,null,null,null,19037050,null,null,null,null,0,[3],3,null,null,null,null,null,null,null,null,null,null,null,[0,2],null,null,null,null,0,null,[2,5,\\\"sd\\\",95],null,null,0,0,1]\",null,null,null,null,null,null,-19800,[null,null,null,\"[null,null,[3701290]]\"],null,null,null,null,3],[\"1707364848777\",null,null,null,null,null,null,\"[36,40400,538,1,\\\"604369551.0\\\","
		"\\\"TFTEZeuNE9zPseMPjtuekAs\\\",null,null,null,\\\"en\\\",\\\"IND\\\",0,8,5860,null,0,0,null,\\\"og-1f203e31-874b-4a44-bf6e-a57fbdc36c71\\\",null,null,null,null,593,null,null,32938,null,null,null,19037050,null,null,null,null,null,null,4,-1,null,null,null,76,256,879,1249,null,null,null,[0,2,1,0,0],null,null,null,null,0,null,[2,5,\\\"sd\\\",95],null,null,0,0,1]\",null,null,null,null,null,null,-19800,[null,null,null,\"[null,null,[3701290]]\"],null,null,null,null,4]],\"1707364849196\",null,null,null,"
		"null,null,null,null,null,null,null,null,null,null,[[null,[null,null,null,null,null,null,null,null,null,null,null,null,122505695]],9]]", 
		LAST);

	/* selecting image */

	/* selecting Hindi */

	return 0;
}