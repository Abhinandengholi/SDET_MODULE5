Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=121", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://www.gstatic.com/og/_/ss/k=og.qtm.8RUPaHb7e5o.L.W.O/m=qcwid/excm=qaaw,qadd,qaid,qein,qhaw,qhba,qhbr,qhch,qhga,qhid,qhin/d=1/ed=1/ct=zgms/rs=AA2YrTungzasoekTaLKrPFUaQFpakqDmnA", "Referer=https://www.google.com/", ENDITEM, 
		"Url=https://www.gstatic.com/og/_/js/k=og.qtm.en_US.ZEEp2pdSHOQ.2019.O/rt=j/m=qabr,q_d,qcwid,qapid,qald,q_dg/exm=qaaw,qadd,qaid,qein,qhaw,qhba,qhbr,qhch,qhga,qhid,qhin/d=1/ed=1/rs=AA2YrTvRRKYp7I5vTn-AtFvme6Qlo6hq9Q", "Referer=https://www.google.com/", ENDITEM, 
		"Url=https://content-autofill.googleapis.com/v1/pages/ChVDaHJvbWUvMTIxLjAuNjE2Ny4xNDASGQn11VQ7sgCk8RIFDWlIR0chrbMLunyG1js=?alt=proto", "Referer=", ENDITEM, 
		LAST);

	web_add_cookie("1P_JAR=2024-02-05-10; DOMAIN=ogs.google.com");

	web_add_cookie("AEC=Ae3NU9O5t3sPp8v6g79RfY2hsPCR-7gSIYZVhFlJNdl8MXlaOljzrBtnJjM; DOMAIN=ogs.google.com");

	web_add_cookie("NID=511=JxCAVDmp96jP_PMxVHbgi53wRu_CkSurIwY6yQW70xmrV6EfNfKGrT-7VuSQkuo8sfiTvkuVs-N11ZKnMJ03gau1I2cA19pw4xnp0GBo2vyX15pGNHNonmUXLbtbvHOpYugeTHlcUQR0e8a_CL2j_Q99i4kmT28eA6D6rpMC5uGB9YkfuX7fuBY; DOMAIN=ogs.google.com");

	web_add_cookie("1P_JAR=2024-02-05-10; DOMAIN=apis.google.com");

	web_add_cookie("AEC=Ae3NU9O5t3sPp8v6g79RfY2hsPCR-7gSIYZVhFlJNdl8MXlaOljzrBtnJjM; DOMAIN=apis.google.com");

	web_add_cookie("NID=511=JxCAVDmp96jP_PMxVHbgi53wRu_CkSurIwY6yQW70xmrV6EfNfKGrT-7VuSQkuo8sfiTvkuVs-N11ZKnMJ03gau1I2cA19pw4xnp0GBo2vyX15pGNHNonmUXLbtbvHOpYugeTHlcUQR0e8a_CL2j_Q99i4kmT28eA6D6rpMC5uGB9YkfuX7fuBY; DOMAIN=apis.google.com");

	web_url("callout", 
		"URL=https://ogs.google.com/widget/callout?prid=19037050&pgid=19037049&puid=a5627eb5c02923db&cce=1&dc=1&origin=https%3A%2F%2Fwww.google.com&cn=callout&pid=1&spid=538&hl=en", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.google.com/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://apis.google.com/_/scs/abc-static/_/js/k=gapi.gapi.en.GsbA68hXs80.O/m=gapi_iframes,googleapis_client/rt=j/sv=1/d=1/ed=1/rs=AHpOoo899t-H8Lxb3OqzMDuPn6TV_i36ag/cb=gapi.loaded_0", "Referer=https://www.google.com/", ENDITEM, 
		"Url=https://fonts.gstatic.com/s/googlesans/v58/4Ua_rENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RFD48TE63OOYKtrw2IJllpyk.woff2", "Referer=https://ogs.google.com/", ENDITEM, 
		"Url=https://fonts.gstatic.com/s/roboto/v18/KFOmCnqEu92Fr1Mu4mxK.woff2", "Referer=https://ogs.google.com/", ENDITEM, 
		"Url=https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRfwK31jSJoDS3wX4ZH2v5k49PLfabZSu90SO1eas4kL7IzpqiVbtXHE2Q&s=10", "Referer=https://www.google.com/", ENDITEM, 
		"Url=https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT375qtPUYZr0WqxFfh87bLvb-B0jFIiul_rGBFJyMb2eP8yx_JZy5Z_6c&s=10", "Referer=https://www.google.com/", ENDITEM, 
		"Url=https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT5bCs10a0XxK1ikEHN655AT_iHkXWJhAsmMUB_IEk&s=10", "Referer=https://www.google.com/", ENDITEM, 
		"Url=https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSt4Zvuqg17L8xiVfbOLSa2Ljl60znIOJHhMXuDqX70yrRBHrTowpAOX2w&s=10", "Referer=https://www.google.com/", ENDITEM, 
		"Url=https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRlgZ1SJEvRn2_isOlZ5L7hfWkcnd-87VcUEcC7Rt_eE-UFwh4-u1N4j4wC&s=10", "Referer=https://www.google.com/", ENDITEM, 
		LAST);

	lr_think_time(13);

	web_custom_request("json", 
		"URL=http://update.googleapis.com/service/update2/json?cup2key=13:B8XSIE0i2aHUMP8mM_39M-24I6WLlM3f-JvQ5GblzYw&cup2hreq=8efc943c24bf2da9cf009f7a63c45b653e64aaafe24a21d330fe5ccf56b0ba07", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx3,puff\",\"app\":[{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.30f5f886b824ca1efde5174370fc03cab3c02e9c309bc381857430f5843a510b\"}]},\"ping\":{\"ping_freshness\":\"{c8b3aec6-6fe7-455c-adff-1591af5383d9}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"1.3.36.311\"},{\"appid\":\""
		"neifaoindggfcjicffkgpmnlppeffabd\",\"brand\":\"GGLS\",\"cohort\":\"1:1299:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.c900ba9a2d8318263fd43782ee6fd5fb50bad78bf0eb2c972b5922c458af45ed\"}]},\"ping\":{\"ping_freshness\":\"{f3b0898b-9fe6-4fce-9d7f-993ac4d131ce}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"1.0.2738.0\"},{\"accept_locale\":\"ENGB500000\",\"appid\":\"obedbbhbpmojnkanicioggnmelmoomoc\",\"brand\":\"GGLS\",\""
		"cohort\":\"1:s6f/20ol:20or@0.5\",\"cohortname\":\"Rollout\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.8069f8805123f74944304604381770bb694317c9e1044e096f540222dc56c0f6\"}]},\"ping\":{\"ping_freshness\":\"{85b64971-ad94-4c7d-956c-98bea00a9947}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"20230923.567854667.14\"},{\"appid\":\"lmelglejhemejginpboagddgdfbepgmp\",\"brand\":\"GGLS\",\"cohort\":\"1:lwl:\",\"cohortname\":\"Auto\",\"enabled\":true,\""
		"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.cadbf9a5f27721576d77d35576f37ca01ac34d86bce73958bf71cde62af71b48\"}]},\"ping\":{\"ping_freshness\":\"{6ca34c83-da07-423d-b790-509ef6107e34}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"432\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"GGLS\",\"cohort\":\"1:j5l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\""
		"1.fd515ec0dc30d25a09641b8b83729234bc50f4511e35ce17d24fd996252eaace\"}]},\"ping\":{\"ping_freshness\":\"{d0c935be-d5a2-43c4-9330-c4671f5d46ca}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"GGLS\",\"cohort\":\"1:cux:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.f4f1eb04881095d1cc8f2e1799a8144c10476dc1088a03ecdb4418644040a554\"}]},\"ping\":{\"ping_freshness\""
		":\"{dfa43690-dd89-40ab-af42-0c3bd1b405b9}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"63\"},{\"appid\":\"jamhcnnkihinmdlkakkaopbjbbcngflc\",\"brand\":\"GGLS\",\"cohort\":\"1:wvr:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.c52c62a7c50daf7d3f73ec16977cd4b0ea401710807d5dbe3850941dd1b73a70\"}]},\"ping\":{\"ping_freshness\":\"{6943185c-2138-4274-b300-e50d9ab5c276}\",\"rd\":6243},\"updatecheck\":{},\"version\":\""
		"120.0.6050.0\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"GGLS\",\"cohort\":\"1:1zdx:\",\"cohortname\":\"Chrome 106+\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{7c1e6213-fa7d-4a45-9a5a-ae4e81102c2b}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"4.10.2710.0\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\""
		"fp\":\"1.3a118962ef814c91f6476bb9f0de58afa63103af6ac1b8729be9b39a86789e96\"}]},\"ping\":{\"ping_freshness\":\"{e0569c35-cd61-4031-9d6b-c5e6705ee0bd}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"1.0.0.15\"},{\"appid\":\"laoigpblnllgcgjnjnllmfolckpjlhki\",\"brand\":\"GGLS\",\"cohort\":\"1:10zr:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{8ecbb538-1995-498c-a79f-7bf985a6d82e}\",\"rd\":6243},\"updatecheck\":{},\"version\":\""
		"1.0.7.1652906823\"},{\"appid\":\"efniojlnjndmcbiieegkicadnoecjjef\",\"brand\":\"GGLS\",\"cohort\":\"1:18ql:\",\"cohortname\":\"Auto Stage3\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.e4bdca96fb46d22bc12f5bc5bdb5cdb518555fd1762653f8afc96d06b34ec74b\"}]},\"ping\":{\"ping_freshness\":\"{34f6766f-a494-4a6b-86f4-3a78ea9a668b}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"852\"},{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\"brand\":\"GGLS\",\""
		"cohort\":\"1:s7x:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.887c873b6c3a26844482754c8534268fcd848b8c543b652626b4d4ec367f26fd\"}]},\"ping\":{\"ping_freshness\":\"{2d926c91-1a80-402b-a4d3-67b2c7128cd2}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"3017\"},{\"appid\":\"ggkkehgbnfjpeggfpleeakpidbkibbmn\",\"brand\":\"GGLS\",\"cohort\":\"1:ut9/1a0f:23ml@0.1\",\"cohortname\":\"M108 and Above\",\"enabled\":true,\""
		"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.c45cd56a0a8da0883c8f9757b31891d6c628f38cb80724015ffdf33b419a73f3\"}]},\"ping\":{\"ping_freshness\":\"{2f991646-6905-420f-b8f3-70ad496b25f0}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"2023.11.27.1202\"},{\"appid\":\"ojhpjlocmbogdgmfpkhlaaeamibhnphh\",\"brand\":\"GGLS\",\"cohort\":\"1:w0x:\",\"cohortname\":\"All users\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\""
		"1.545666a4efd056351597bb386aea1368105ededc976ed5650d8682daab9f37ff\"}]},\"ping\":{\"ping_freshness\":\"{c920ada3-fd49-4df4-bd07-aa36df30595b}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"3\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"GGLS\",\"cohort\":\"1:jcl:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.b639cc0f057b0d472ba8827f557f9a745e640af0a4ccf5d3a7c77e944343ae6e\"}]},\"ping\":{\"ping_freshness\""
		":\"{9d096e43-cff9-46cd-b5e7-d59590cb1427}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"8528\"},{\"appid\":\"jflhchccmppkfebkiaminageehmchikm\",\"brand\":\"GGLS\",\"cohort\":\"1:26yf:\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":6150,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.1ef9f0df4172bd73d0dd61c5b9f31c13df8522d4581a638a37be32dad0d920c4\"}]},\"ping\":{\"ping_freshness\":\"{12f5b773-598e-48b3-b019-3b1739160ae3}\",\"rd\":6243},\"updatecheck\":{},\"version\":\""
		"2024.2.3.1\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"GGLS\",\"cohort\":\"1:bm1:\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.cd1978742a4afdbaaa15bf712d5c90bef4144caa99024df98f6a9ad58043ae85\"}]},\"ping\":{\"ping_freshness\":\"{ff1d972a-dc23-4b97-aada-3c87a9aa3699}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"9.49.1\"},{\"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\"brand\":\"GGLS\",\"cohort\":"
		"\"1:ofl:\",\"cohortname\":\"stable64\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.a8a79d350c2a5e3bc36226633a8e0bed0dfab184e77f38fc8f0820ebacf8eafc\"}]},\"ping\":{\"ping_freshness\":\"{a7046807-4af9-46a0-bd89-9ffeeaa621a7}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"2018.8.8.0\"},{\"appid\":\"kiabhabjdbkjdpjbpigfodbdjmbglcoo\",\"brand\":\"GGLS\",\"cohort\":\"1:v3l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6133,\"lang\":\""
		"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.4a6508925b2ffec931c1e3931ddeb15ca41d820a8264cd5a962b526e9932bcdf\"}]},\"ping\":{\"ping_freshness\":\"{5b65a395-c1ea-4b77-a620-cbab3c32cf31}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"2024.1.2.1\"},{\"appid\":\"eeigpngbgcognadeebkilcpcaedhellh\",\"brand\":\"GGLS\",\"cohort\":\"1:w59:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\""
		"1.c64c9c1008f3ba5f6e18b3ca524bc98dcd8acfae0a2720a8f1f3ef0f8d643d05\"}]},\"ping\":{\"ping_freshness\":\"{4ac9df2c-877e-41bc-b318-303ca043fb06}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"2020.11.2.164946\"},{\"appid\":\"gonpemdgkjcecdgbnaabipppbmgfggbe\",\"brand\":\"GGLS\",\"cohort\":\"1:z1x:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.48fecfa3c6f59eb6c34fdd5e8f19e0678699e2f27dc8ebfa7025c246d4575c68\"}]},\"ping\":{\""
		"ping_freshness\":\"{4e9dd908-72d6-4dbd-9d7b-c374eae9e6a5}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"2024.1.17.0\"},{\"appid\":\"niikhdgajlphfehepabhhblakbdgeefj\",\"brand\":\"GGLS\",\"cohort\":\"1:1uh3:\",\"cohortname\":\"Auto Main Cohort.\",\"enabled\":true,\"installdate\":6133,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.738f6ed18eb59593934e529fa42f819ee99067eb187a687a24c2a940bae078d3\"}]},\"ping\":{\"ping_freshness\":\"{d47cffd8-65e0-491c-96c9-07a428cde6e0}\",\"rd\":6243},\""
		"updatecheck\":{},\"version\":\"2024.1.31.0\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":true,\"physmemory\":12,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.19045.3324\"},\"prodversion\":\"121.0.6167.140\",\"protocol\":\"3.1\",\"requestid\":\"{c42c68e6-b1e6-4ce7-bdda-2cb593e29b10}\",\"sessionid\":\""
		"{f44b0d92-806c-49c4-8663-af355416d0d0}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"laststarted\":0,\"name\":\"ChromiumUpdater\",\"updatepolicy\":-1,\"version\":\"123.0.6268.0\"},\"updaterversion\":\"121.0.6167.140\"}}", 
		EXTRARES, 
		"Url=https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcQfckeP2jtbHJlXra0Abnq7Kbf0eQ6iVg8Snltj4_Sdb0EFjwHyP8A", "Referer=https://www.google.com/", ENDITEM, 
		"Url=https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcRtTAzc2YkpjeeHuAZMrdHXdjLC08MmdAY8f-kcSqO9yjz_IHpIsYE2-ICyu9vsgxXPXxo", "Referer=https://www.google.com/", ENDITEM, 
		"Url=https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcQyOqARvJ5ODGOAg4NOKD7nGQ_wFDazMrH30KQi3QE81jLS9PpHnI4AGhhAXLN5XTN3pts", "Referer=https://www.google.com/", ENDITEM, 
		LAST);

	return 0;
}